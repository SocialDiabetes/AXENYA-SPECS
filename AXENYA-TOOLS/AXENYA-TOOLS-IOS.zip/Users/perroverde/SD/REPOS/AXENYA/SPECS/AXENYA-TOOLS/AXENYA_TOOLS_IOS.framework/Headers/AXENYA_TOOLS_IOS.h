//
//  AXENYA_TOOLS_IOS.h
//  AXENYA_TOOLS_IOS
//
//  Created by Jose Ferré on 25/05/2020.
//  Copyright © 2020 CocoaPods. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for AXENYA_TOOLS_IOS.
FOUNDATION_EXPORT double AXENYA_TOOLS_IOSVersionNumber;

//! Project version string for AXENYA_TOOLS_IOS.
FOUNDATION_EXPORT const unsigned char AXENYA_TOOLS_IOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AXENYA_TOOLS_IOS/PublicHeader.h>


